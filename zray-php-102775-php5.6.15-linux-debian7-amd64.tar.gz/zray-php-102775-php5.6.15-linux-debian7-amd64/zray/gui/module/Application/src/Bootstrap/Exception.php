<?php

namespace Bootstrap;

use ZendServer\Exception as baseException;

class Exception extends baseException {
}

