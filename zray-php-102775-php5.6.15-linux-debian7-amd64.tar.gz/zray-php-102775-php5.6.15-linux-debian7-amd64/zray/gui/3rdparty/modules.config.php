<?php

return array(
	'modules' => array(
//         'ZRayExtensionMagento'
//			'ZRayExtensionWordpress',
	)
);
